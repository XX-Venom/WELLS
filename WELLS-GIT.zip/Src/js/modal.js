


    setTimeout(() => {
        var modal = document.querySelector('.modal')
        var body = document.querySelector('body')
        body.style.overflow = 'hidden'
        modal.style.paddingTop = '0px'
        modal.style.transition = 'all .5s'
      }, 60); 